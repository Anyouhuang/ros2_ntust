import os
from launch import LaunchDescription
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder

def generate_launch_description():
    # 1. 讀取你設定好的 MoveIt 參數
    moveit_config = (
        MoveItConfigsBuilder("hiwin_ra605", package_name="ay_moveit_config")
        .to_moveit_configs()
    )

    # 2. 手動建立 move_group 節點，並在這裡強行注入模擬時間！
    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[
            moveit_config.to_dict(),
            {"use_sim_time": True},  # ⭕️ 解決 No Planning Scene Loaded 的關鍵！
        ],
    )

    # 3. 回傳啟動描述
    return LaunchDescription([move_group_node])
