import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import tkinter as tk
import threading
import math  # 引入 math 模組來處理度數與弧度的轉換

class SliderController(Node):
    def __init__(self):
        super().__init__('slider_controller')
        
        # 設定發布者，發布至 /joint_states
        self.publisher_ = self.create_publisher(JointState, '/joint_states', 10)
        
        self.joint_names = [
            'joint_1', 'joint_2', 'joint_3', 
            'joint_4', 'joint_5', 'joint_6'
        ]
        # 內部儲存的關節位置 (維持 ROS 2 要求的弧度)
        self.joint_positions = [0.0] * 6

        # 設定計時器，每 50 毫秒 (20Hz) 更新一次關節狀態
        self.timer = self.create_timer(0.05, self.timer_callback)

    def timer_callback(self):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.joint_names
        msg.position = self.joint_positions
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SliderController()

    # --- 建立 Tkinter 圖形化介面 ---
    root = tk.Tk()
    root.title("RA605 真實角度控制器 (度數)")
    root.geometry("450x380")

    # 根據 HIWIN RA605 設定各軸的安全極限 (改為真實度數 Degrees)
    limits_deg = [
        (-165, 165),   # J1
        (-125, 85),    # J2
        (-55, 185),    # J3
        (-190, 190),   # J4
        (-115, 115),   # J5
        (-360, 360)    # J6
    ]

    # 當滑桿被拖動時，讀取介面的度數，並轉換為弧度存入 ROS 2 節點
    def update_joints(val):
        for i in range(6):
            # math.radians() 會自動將度數轉為弧度
            degree_val = sliders[i].get()
            node.joint_positions[i] = math.radians(degree_val)

    sliders = []
    # 動態生成 6 個滑桿
    for i in range(6):
        frame = tk.Frame(root)
        frame.pack(fill=tk.X, padx=10, pady=8)
        
        # 標籤加上度數符號提示
        label = tk.Label(frame, text=f"Joint {i+1} (°):", width=12, anchor="w", font=("Arial", 10, "bold"))
        label.pack(side=tk.LEFT)
        
        # 將解析度 (resolution) 改為 1 度，滑動起來更符合直覺
        slider = tk.Scale(frame, from_=limits_deg[i][0], to=limits_deg[i][1], 
                          resolution=1, orient=tk.HORIZONTAL, 
                          length=280, command=update_joints)
        slider.pack(side=tk.RIGHT)
        sliders.append(slider)

    # 建立一個獨立的執行緒來讓 ROS 2 節點保持運作
    ros_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    ros_thread.start()

    # 啟動 Tkinter UI 迴圈
    root.mainloop()

    # 關閉視窗後的清理工作
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
